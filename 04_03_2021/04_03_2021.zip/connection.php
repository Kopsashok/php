<?php 
	$host="localhost";
	$db="hospital";
	$un="root";
	$pw="";
	$con=new mysqli($host,$un,$pw,$db) or die("Db not connected");
 ?>